from django.apps import AppConfig


class EventcalendarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'eventcalendar'
    verbose_name = 'Event Calendar'
